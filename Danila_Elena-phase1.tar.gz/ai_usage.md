Model AI: Gemini 3 Flash



Prompt-uri:
1.Specificatii + vreau ca functia parse_condition sa faca split in 3 parti a string ului field:operator:value, dat fiind ca stuctura mea report_t arata asa: typedef struct {

    int rid;

    char name[50];

    float latitude;

    float longitude;

    char cat_issue[50];

    int severity;

    time_t timestamp;

    char description[256];

} Report_t;
2. Functia match_condition: primul argument vreau sa fie de tip report_t ca in codul meu, vreau ca valoarea de return sa fie 1 daca conditiile sunt satisfacute sau 0 daca conditiile nu sunt satisfacute;
3. exista o varianta de a optimiza functia match? ce optimizari sugerezi?;
4. explica-mi cum ar arata o implementare cu switch in functia match;
5. explica-mi linie cu linie functiile match si parse;



Materiale trimise catre AI:
- fisierul cu specificatii;
- structura Report_t pentru denumirea campurilor



Raspuns AI:
-Functia match_condition:
/**
 * Verifica daca un record de tip Report_t satisface o conditie specifica.
 * Returneaza 1 daca este adevarat, 0 in caz contrar.
 */
int match_condition(Report_t *r, const char *field, const char *op, const char *value) {
    if (r == NULL || field == NULL || op == NULL || value == NULL) return 0;

    // --- Tratare campuri de tip INT (severity, rid, timestamp) ---
    if (strcmp(field, "severity") == 0 || strcmp(field, "rid") == 0 || strcmp(field, "timestamp") == 0) {
        long r_val;
        if (strcmp(field, "severity") == 0) r_val = r->severity;
        else if (strcmp(field, "rid") == 0) r_val = r->rid;
        else r_val = (long)r->timestamp;

        long val_to_compare = atol(value);

        if (strcmp(op, "==") == 0) return r_val == val_to_compare;
        if (strcmp(op, "!=") == 0) return r_val != val_to_compare;
        if (strcmp(op, "<") == 0)  return r_val < val_to_compare;
        if (strcmp(op, "<=") == 0) return r_val <= val_to_compare;
        if (strcmp(op, ">") == 0)  return r_val > val_to_compare;
        if (strcmp(op, ">=") == 0) return r_val >= val_to_compare;
    }

    // --- Tratare campuri de tip STRING (category, inspector/name) ---
    else if (strcmp(field, "category") == 0 || strcmp(field, "inspector") == 0) {
        char *r_str;
        if (strcmp(field, "category") == 0) r_str = r->cat_issue;
        else r_str = r->name;

        if (strcmp(op, "==") == 0) return strcmp(r_str, value) == 0;
        if (strcmp(op, "!=") == 0) return strcmp(r_str, value) != 0;
        // Pentru string-uri, operatorii <, >, <=, >= se bazeaza pe ordinea lexicografica
        if (strcmp(op, "<") == 0)  return strcmp(r_str, value) < 0;
        if (strcmp(op, "<=") == 0) return strcmp(r_str, value) <= 0;
        if (strcmp(op, ">") == 0)  return strcmp(r_str, value) > 0;
        if (strcmp(op, ">=") == 0) return strcmp(r_str, value) >= 0;
    }

    return 0; // Camp necunoscut
}

- Functia parse_condition:
int parse_condition(const char *input, char *field, char *op, char *value) {
    if (input == NULL || field == NULL || op == NULL || value == NULL) {
        return 0;
    }

    char temp[256];
    strncpy(temp, input, sizeof(temp) - 1);
    temp[sizeof(temp) - 1] = '\0';

    char *token;

    token = strtok(temp, ":");
    if (token == NULL) return 0;
    strcpy(field, token);

    token = strtok(NULL, ":");
    if (token == NULL) return 0;
    strcpy(op, token);

    token = strtok(NULL, ":");
    if (token == NULL) return 0;
    strcpy(value, token);

    return 1;
}



Ce am schimbat din raspunsul AI ului?
- mici optimizari ale functiei match;
- am renuntat la varianta functiei match cu switch;